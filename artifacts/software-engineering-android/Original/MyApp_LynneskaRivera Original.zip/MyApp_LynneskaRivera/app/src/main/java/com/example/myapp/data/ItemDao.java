package com.example.myapp.data;


import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.myapp.model.Item;
import java.util.ArrayList; import java.util.List;

public class ItemDao {
    private final AppDatabase helper;
    public ItemDao(AppDatabase h) { this.helper = h; }

    public long insert(Item item) {
        ContentValues cv = new ContentValues();
        cv.put("name", item.name);
        cv.put("qty", item.qty);
        cv.put("date", item.date);
        return helper.getWritableDatabase().insert("items", null, cv);
    }

    public int update(Item item) {
        ContentValues cv = new ContentValues();
        cv.put("name", item.name);
        cv.put("qty", item.qty);
        cv.put("date", item.date);
        return helper.getWritableDatabase().update("items", cv, "id=?",
                new String[]{String.valueOf(item.id)});
    }

    public int delete(int id) {
        return helper.getWritableDatabase().delete("items", "id=?",
                new String[]{String.valueOf(id)});
    }

    public List<Item> listAll() {
        List<Item> result = new ArrayList<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT id, name, qty, date FROM items ORDER BY id DESC", null)) {
            while (c.moveToNext()) {
                Item it = new Item();
                it.id = c.getInt(0); it.name = c.getString(1);
                it.qty = c.getInt(2); it.date = c.getString(3);
                result.add(it);
            }
        }
        return result;
    }
}
