package com.example.myapp.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.myapp.R;

public class MainActivity extends AppCompatActivity {

    private boolean smsGranted = false;
    private TextView tvPermissionStatus;

    private final ActivityResultLauncher<String> smsPermLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                smsGranted = granted;
                String msg = granted ? "Permission: Granted" : "Permission: Denied";
                if (tvPermissionStatus != null) tvPermissionStatus.setText(msg);
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // your SMS-only layout

        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);
        Button btnRequest = findViewById(R.id.btnCheckOrRequest);

        if (btnRequest != null) {
            btnRequest.setOnClickListener(v -> requestSmsPermission());
        }

        // Optional: reflect current permission state on first launch
        updatePermissionStatus();
    }

    private void updatePermissionStatus() {
        boolean granted = (Build.VERSION.SDK_INT < 23) ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED;
        smsGranted = granted;
        if (tvPermissionStatus != null) {
            tvPermissionStatus.setText(granted ? "Permission: Granted" : "Permission: Not granted");
        }
    }

    private void requestSmsPermission() {
        if (Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                        != PackageManager.PERMISSION_GRANTED) {
            smsPermLauncher.launch(Manifest.permission.SEND_SMS);
        } else {
            smsGranted = true;
            if (tvPermissionStatus != null) tvPermissionStatus.setText("Permission: Granted");
            Toast.makeText(this, "Permission: Granted", Toast.LENGTH_SHORT).show();
        }
    }
}
