package com.example.myapp.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myapp.R;
import com.example.myapp.model.Item;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.VH> {

    public interface Listener {
        void onEdit(Item item);   // we’ll call this on row tap to increment qty
        void onDelete(Item item); // delete button
    }

    private List<Item> data;
    private final Listener listener;

    public ItemAdapter(List<Item> data, Listener listener) {
        this.data = data;
        this.listener = listener;
    }

    public void setData(List<Item> newData) {
        this.data = newData;
        notifyDataSetChanged();
    }

    static class VH extends RecyclerView.ViewHolder {
        View root;
        TextView tvItemName, tvMeta;
        Button btnDelete;

        VH(View v) {
            super(v);
            root = v;
            tvItemName = v.findViewById(R.id.tvItemName);
            tvMeta = v.findViewById(R.id.tvMeta);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_data_row, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Item it = data.get(position);
        h.tvItemName.setText(it.name);
        String datePart = (it.date == null || it.date.isEmpty()) ? "--/--" : it.date;
        h.tvMeta.setText("Qty: " + it.qty + "  •  Date: " + datePart);

        // Row tap = "Edit" (increment qty)
        h.root.setOnClickListener(v -> listener.onEdit(it));

        // Delete button
        h.btnDelete.setOnClickListener(v -> listener.onDelete(it));
    }

    @Override
    public int getItemCount() {
        return (data == null) ? 0 : data.size();
    }
}