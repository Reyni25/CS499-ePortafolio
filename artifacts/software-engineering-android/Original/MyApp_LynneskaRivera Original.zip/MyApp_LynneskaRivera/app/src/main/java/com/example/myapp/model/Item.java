package com.example.myapp.model;

public class Item {
    public int id;
    public String name;
    public int qty;
    public String date; // optional yyyy-MM-dd
}
