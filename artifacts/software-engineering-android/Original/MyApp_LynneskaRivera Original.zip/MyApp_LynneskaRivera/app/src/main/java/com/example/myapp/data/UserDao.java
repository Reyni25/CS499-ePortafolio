package com.example.myapp.data;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Base64;
import java.security.MessageDigest;

public class UserDao {
    private final AppDatabase helper;
    public UserDao(AppDatabase helper) { this.helper = helper; }

    public boolean usernameExists(String username) {
        SQLiteDatabase db = helper.getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT 1 FROM users WHERE username=? LIMIT 1",
                new String[]{username})) { return c.moveToFirst(); }
    }

    public long createUser(String username, String rawPassword) {
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("password_hash", hash(rawPassword));
        cv.put("created_at", System.currentTimeMillis());
        return helper.getWritableDatabase().insert("users", null, cv);
    }

    public boolean validate(String username, String rawPassword) {
        SQLiteDatabase db = helper.getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT password_hash FROM users WHERE username=?",
                new String[]{username})) {
            if (!c.moveToFirst()) return false;
            return c.getString(0).equals(hash(rawPassword));
        }
    }

    private static String hash(String raw) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] out = md.digest(raw.getBytes("UTF-8"));
            return Base64.encodeToString(out, Base64.NO_WRAP);
        } catch (Exception e) { return ""; }
    }
}
