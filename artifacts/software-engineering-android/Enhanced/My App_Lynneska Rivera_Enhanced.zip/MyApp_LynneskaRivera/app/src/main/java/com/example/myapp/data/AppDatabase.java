package com.example.myapp.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AppDatabase extends SQLiteOpenHelper {
    public static final String DB_NAME = "yourapp.db";
    private static final int DB_VERSION = 2;

    public AppDatabase(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE IF NOT EXISTS users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT UNIQUE NOT NULL, " +
                        "hash TEXT NOT NULL, " +      // PBKDF2 hash
                        "salt TEXT NOT NULL" +        // base64 salt
                        ")"
        );

        db.execSQL(
                "CREATE TABLE IF NOT EXISTS items (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL, " +
                        "qty INTEGER NOT NULL, " +
                        "date TEXT" +
                        ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // simplest dev strategy: drop and recreate users table
            db.execSQL("DROP TABLE IF EXISTS users");
            db.execSQL(
                    "CREATE TABLE users (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "username TEXT UNIQUE NOT NULL, " +
                            "hash TEXT NOT NULL, " +
                            "salt TEXT NOT NULL" +
                            ")"
            );

        }


    }
}