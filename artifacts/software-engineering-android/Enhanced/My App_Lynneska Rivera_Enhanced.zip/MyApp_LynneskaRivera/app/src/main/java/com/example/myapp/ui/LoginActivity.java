package com.example.myapp.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapp.R;
import com.example.myapp.data.AppDatabase;
import com.example.myapp.data.UserDao;
import com.example.myapp.DataGridActivity;



public class LoginActivity extends AppCompatActivity {

    private EditText etUser, etPass;
    private Button btnLogin, btnCreate;
    private UserDao userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Bind UI elements to variables
        etUser = findViewById(R.id.editUsername);
        etPass = findViewById(R.id.editPassword);
        btnLogin = findViewById(R.id.buttonLogin);
        btnCreate = findViewById(R.id.buttonCreateAccount);

        // Create database helper
        userDao = new UserDao(new AppDatabase(this));

        // Login button → validates existing user
        btnLogin.setOnClickListener(this::onLoginClicked);

        // Create Account button → registers new user
        btnCreate.setOnClickListener(this::onCreateClicked);
    }

    /** Handle Login button click */
    private void onLoginClicked(View v) {
        String username = etUser.getText().toString().trim();
        String password = etPass.getText().toString();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (userDao.validate(username, password)) {
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            goToMain();
        } else {
            Toast.makeText(this, "Invalid credentials. Try again or create an account.", Toast.LENGTH_SHORT).show();
        }
    }

    /** Handle Create Account button click */
    private void onCreateClicked(View v) {
        String username = etUser.getText().toString().trim();
        String password = etPass.getText().toString();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (userDao.usernameExists(username)) {
            Toast.makeText(this, "Username already exists. Please log in.", Toast.LENGTH_SHORT).show();
            return;
        }

        long id = userDao.createUser(username, password);
        if (id > 0) {
            Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
            goToMain();
        } else {
            Toast.makeText(this, "Error creating account.", Toast.LENGTH_SHORT).show();
        }
    }

    /** Navigates to the main screen */
    /** Navigates to the main screen */
    private void goToMain() {
        Intent intent = new Intent(this, DataGridActivity.class);
        startActivity(intent);
        finish();
    }


}
