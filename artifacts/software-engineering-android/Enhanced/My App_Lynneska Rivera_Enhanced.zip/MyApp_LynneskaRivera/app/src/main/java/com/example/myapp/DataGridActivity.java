package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapp.ui.LoginActivity;

/**
 * Author: Lynneska Rivera
 * Course: CS 499
 * Purpose: Displays inventory data grid and allows logout.
 */
public class DataGridActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Show the inventory layout
        setContentView(R.layout.activity_data_grid);

        // Wire up buttons
        Button btnAdd = findViewById(R.id.buttonAddData);
        Button btnLogout = findViewById(R.id.buttonBack); // this is the bottom button in your XML

        // TODO: hook up Add button to open your "add item" screen or dialog later
        // For now it can stay as-is or be wired to whatever logic you already had.

        // Logout: go back to LoginActivity
        btnLogout.setOnClickListener(v -> logout());
    }

    private void logout() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish(); // prevent back button from returning here
    }
}
