package com.example.myapp.data;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.myapp.util.PasswordUtils;

public class UserDao {
    private final AppDatabase helper;

    public UserDao(AppDatabase helper) {
        this.helper = helper;
    }

    public boolean usernameExists(String username) {
        SQLiteDatabase db = helper.getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT 1 FROM users WHERE username=? LIMIT 1",
                new String[]{username})) {
            return c.moveToFirst();
        }
    }

    public long createUser(String username, String rawPassword) {
        SQLiteDatabase db = helper.getWritableDatabase();

        // Generate salt and hash using PBKDF2
        byte[] salt = PasswordUtils.newSalt();
        String hash = PasswordUtils.hash(rawPassword.toCharArray(), salt);

        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("hash", hash);                      // matches AppDatabase
        cv.put("salt", PasswordUtils.b64(salt));   // store salt as Base64 text

        return db.insert("users", null, cv);
    }


    public boolean validate(String username, String rawPassword) {
        SQLiteDatabase db = helper.getReadableDatabase();
        try (Cursor c = db.rawQuery(
                "SELECT hash, salt FROM users WHERE username=? LIMIT 1",
                new String[]{username})) {

            if (!c.moveToFirst()) return false;

            String storedHash = c.getString(0);
            String storedSaltB64 = c.getString(1);
            byte[] salt = PasswordUtils.deb64(storedSaltB64);

            String candidate = PasswordUtils.hash(rawPassword.toCharArray(), salt);

            return storedHash.equals(candidate);
        }
    }


}
