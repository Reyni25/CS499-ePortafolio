package com.example.myapp.util;

import android.content.Context;
import android.telephony.SmsManager;
import android.widget.Toast;

public class SmsHelper {
    public static void send(Context ctx, String phone, String message) {
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null);
            Toast.makeText(ctx, "SMS sent", Toast.LENGTH_SHORT).show();
        } catch (SecurityException se) {
            Toast.makeText(ctx, "SMS permission not granted", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(ctx, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }
}
