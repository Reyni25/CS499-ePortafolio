package com.example.myapp.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapp.DataGridActivity;

/**
 * Author: Lynneska Rivera
 * Course: CS 499
 * Purpose: Main entry after login – routes to inventory screen.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // No SMS permission handling anymore.
        // Immediately navigate to the inventory/grid screen.
        Intent intent = new Intent(this, DataGridActivity.class);
        startActivity(intent);
        finish();
    }
}
