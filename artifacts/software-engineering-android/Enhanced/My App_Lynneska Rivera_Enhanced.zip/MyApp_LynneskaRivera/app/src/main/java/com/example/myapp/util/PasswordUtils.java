package com.example.myapp.util;

import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class PasswordUtils {
    private static final int ITER = 65536;     // ~65k iterations
    private static final int KEY_LEN = 256;    // 256-bit key
    private static final String ALG = "PBKDF2WithHmacSHA256";

    private PasswordUtils() {}

    public static byte[] newSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return salt;
    }

    public static String hash(char[] password, byte[] salt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password, salt, ITER, KEY_LEN);
            byte[] key = SecretKeyFactory.getInstance(ALG).generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(key);
        } catch (Exception e) {
            throw new RuntimeException("PBKDF2 hashing failed", e);
        }
    }

    public static String b64(byte[] bytes) { return Base64.getEncoder().encodeToString(bytes); }
    public static byte[] deb64(String s) { return Base64.getDecoder().decode(s); }
}