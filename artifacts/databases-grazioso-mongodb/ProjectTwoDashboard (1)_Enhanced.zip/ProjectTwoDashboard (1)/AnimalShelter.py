import os
from dotenv import load_dotenv
from pymongo import MongoClient
from bson.objectid import ObjectId
import logging

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username=None, password=None,
                 host='localhost', port=27017,
                 db='AAC', col='animals', auth_source='admin'):
        # Load environment variables from .env
        load_dotenv()

        # If values are not passed in, fall back to environment variables
        username = username or os.getenv("MONGO_USER")
        password = password or os.getenv("MONGO_PASS")
        host = os.getenv("MONGO_HOST", host)
        port = int(os.getenv("MONGO_PORT", port))
        db = os.getenv("MONGO_DB", db)
        col = os.getenv("MONGO_COLLECTION", col)

        try:
            # Build URI that works with or without auth
            if username and password:
                uri = f"mongodb://{username}:{password}@{host}:{port}/?authSource={auth_source}"
            else:
                uri = f"mongodb://{host}:{port}"

            self.client = MongoClient(uri)
            self.database = self.client[db]
            self.collection = self.database[col]

            # 🔹 Enhancement: create indexes to improve query performance
            self.collection.create_index("animal_type")
            self.collection.create_index("breed")
            self.collection.create_index("age_upon_outcome")
            self.collection.create_index("outcome_type")

            logging.info("MongoDB connection successful and indexes created.")
        except Exception as e:
            logging.error(f"Failed to connect to MongoDB: {e}")
            raise e


    # C: Create
    def create(self, data):
        if data is not None and isinstance(data, dict):
            try:
                insert_result = self.collection.insert_one(data)
                return insert_result.acknowledged
            except Exception as e:
                logging.error(f"Insert failed: {e}")
                return False
        else:
            raise ValueError("Invalid data: must be a non-empty dictionary.")

    # R: Read
    def read(self, query, projection=None):
        if query is not None and isinstance(query, dict):
            try:
                result_cursor = self.collection.find(query, projection) if projection else self.collection.find(query)
                return list(result_cursor)
            except Exception as e:
                logging.error(f"Read failed: {e}")
                return []
        else:
            raise ValueError("Query must be a dictionary.")

