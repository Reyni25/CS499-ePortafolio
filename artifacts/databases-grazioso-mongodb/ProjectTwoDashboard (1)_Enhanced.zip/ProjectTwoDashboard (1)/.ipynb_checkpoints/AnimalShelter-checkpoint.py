from pymongo import MongoClient
from bson.objectid import ObjectId
import logging

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, host='localhost', port=34195,
                 db='AAC', col='animals', auth_source='admin'):
        try:
            self.client = MongoClient(
                f'mongodb://{username}:{password}@{host}:{port}/?authSource={auth_source}'
            )
            self.database = self.client[db]
            self.collection = self.database[col]
            logging.info("MongoDB connection successful.")
        except Exception as e:
            logging.error(f"Failed to connect to MongoDB: {e}")
            raise e

    # C: Create
    def create(self, data):
        if data is not None and isinstance(data, dict):
            try:
                insert_result = self.collection.insert_one(data)
                return insert_result.acknowledged
            except Exception as e:
                logging.error(f"Insert failed: {e}")
                return False
        else:
            raise ValueError("Invalid data: must be a non-empty dictionary.")

    # R: Read
    def read(self, query, projection=None):
        if query is not None and isinstance(query, dict):
            try:
                result_cursor = self.collection.find(query, projection) if projection else self.collection.find(query)
                return list(result_cursor)
            except Exception as e:
                logging.error(f"Read failed: {e}")
                return []
        else:
            raise ValueError("Query must be a dictionary.")

